

export class AppConstants {
    public static readonly API_BASE_URL = 'http://192.168.0.106:8091';
    public static readonly IMAGE_BASE_URL = 'http://ec2-13-233-157-98.ap-south-1.compute.amazonaws.com';
    public static readonly USER =  'USER';
    public static readonly CONSULTANT =  'CONSULTANT';
    public static readonly NOT_LOGIN = 'NOT_LOGIN'
}; 