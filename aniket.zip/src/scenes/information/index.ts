export { EducationScreen } from './education.component';
export { ExperienceScreen } from './experience/experience.component';
export { FresherScreen } from './fresher/fresher.component';
export { FresherTechScreen } from './fresher/fresherTech.component';
export { CompanyScreen } from './hr/company.component';