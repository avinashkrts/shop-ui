import React, { Component } from 'react';
import { StyleSheet, Alert, TouchableOpacity, RefreshControl, Dimensions, FlatList } from 'react-native';
import {
  Divider,
  Layout,
  Text,
  Avatar,
  Button,
  Input,
  ListItem,
  ListItemElement,
  List
} from 'react-native-ui-kitten';
import { useState } from "react";
import { AddProductScreenProps } from '../../navigation/home.navigator';
import { Toolbar } from '../../components/toolbar.component';
import {
  SafeAreaLayout,
  SafeAreaLayoutElement,
  SaveAreaInset,
} from '../../components/safe-area-layout.component';
import { AppConstants } from '../../constants/AppConstants';
import { Separator, Container, Content, View, Footer, FooterTab, Form, Picker, Thumbnail, CheckBox } from 'native-base';
import Axios from 'axios';
import { LabelConstants, LableText } from '../../constants/LabelConstants';
import { AsyncStorage } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SearchIcon, HomeIcon, BackIcon } from '../../assets/icons';
// import VideoPlayer from 'react-native-video-player';
import Share from 'react-native-share';
import { MoreScreen } from '../home/more.component'
import { ArrowDownward, ArrowUpward } from '../../assets/icons';
import RouterComponent from '../components/Router'
import { Styles } from '../../assets/styles';
import { TextInput } from 'react-native-gesture-handler';
const HEIGHT = Dimensions.get("window").height;
const WIDTH = Dimensions.get("window").width;

type Mystate = {

}
// const prop = (props: AboutScreenProps):

export class AddProductScreen extends Component<AddProductScreenProps & SafeAreaLayoutElement & any, Mystate & any> {
  constructor(props) {
    super(props)
    this.state = {
      isChecked: false,
      isEnabled: false,


    }
    this.onRefresh = this.onRefresh.bind(this);


  }

  offers() {
    this.setState({ isChecked: !this.state.isChecked })
  }

  onRefresh() {
    this.setState({ refreshing: true });
    this.componentDidMount().then(() => {
      this.setState({ refreshing: false });
    });
  }


  render() {
    const { isEditable, isChecked } = this.state

    return (
      <SafeAreaLayout
        style={Styles.safeArea}
        insets={SaveAreaInset.TOP}>
        <Toolbar
          title=''
          backIcon={BackIcon}
          onBackPress={this.props.navigation.goBack}
          style={{ marginTop: -5, marginLeft: -5 }}
        />
        <Divider />
        <Content style={Styles.content}
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this.onRefresh.bind(this)}
            />
          }
        >
          <View style={[Styles.profile, Styles.center]}>
            <View style={Styles.profile_image}>
              <Avatar source={require("../../assets/profile.jpeg")} style={Styles.profile_avatar} />
            </View>
          </View>

          <Divider />

          <View>
            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.PRODUCT_NAME}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.PRODUCT_NAME} />
              </View>
            </View>

            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.SELLING_PRICE}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput keyboardType='numeric' editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.SELLING_PRICE} />
              </View>
            </View>

            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.COST_PRICE}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput keyboardType='numeric' editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.COST_PRICE} />
              </View>
            </View>


            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.OLD_PRICE}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput keyboardType='numeric' editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.OLD_PRICE} />
              </View>
            </View>



            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.CATEGORY}</Text>
              </View>
              <View style={Styles.user_drop_data}>
                <Picker >
                  <Picker.Item label="Groccery" value="key0" />
                  <Picker.Item label="Customer" value="key1" />
                </Picker>
              </View>
            </View>


            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.BRAND}</Text>
              </View>
              <View style={Styles.user_drop_data}>
                <Picker >
                  <Picker.Item label="Groccery" value="key0" />
                  <Picker.Item label="Customer" value="key1" />
                </Picker>
              </View>
            </View>





            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.QUANTITY}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput keyboardType='numeric' editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.QUANTITY} />
              </View>
            </View>

            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.DESCRIPTION}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput multiline={true} editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.DESCRIPTION} />
              </View>
            </View>

            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.BARCODE}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.BARCODE} />
              </View>
            </View>

            <View style={Styles.user_detail}>
              <View style={Styles.user_detail_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.STOCK}</Text>
              </View>
              <View style={Styles.user_detail_data}>
                <TextInput keyboardType='numeric' editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.STOCK} />
              </View>
            </View>


            <View style={Styles.user_detail}>
              <View style={Styles.user_addproduct_header}>
                <Text style={Styles.user_detail_header_text}>{LableText.OFFER}</Text>
                <View style={{ flexDirection: 'row' }}>
                  <CheckBox
                    checked={isChecked}
                    onPress={() => { this.offers() }}
                  />
                </View>
              </View>


            {isChecked ?
              <View style={Styles.user_drop_box}>
                <View style={Styles.user_add_Product_header_text}>
                  <Text style={Styles.user_add_Product_header_text}>{LableText.DISCOUNT}</Text>
                  <View style={Styles.user_drop_box}>
                    <TextInput editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.DISCOUNT} />
                  </View>
                </View>


                <View style={Styles.user_add_Product_header_text}>
                  <Text style={Styles.user_add_Product_header_text}>{LableText.FROM_DATE}</Text>
                  <View style={Styles.user_drop_box}>
                    <TextInput editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.FROM_DATE} />
                  </View>
                </View>


                <View style={Styles.user_add_Product_header_text}>
                  <Text style={Styles.user_add_Product_header_text}>{LableText.TO_DATE}</Text>
                  <View style={Styles.user_drop_box}>
                    <TextInput editable={isEditable} style={Styles.cash_pay_input} placeholder={LableText.TO_DATE} />
                  </View>
                </View>
              </View> : null}


            </View>
          </View>


          <View style={{ marginHorizontal: '10%' }}>
            <TouchableOpacity style={[Styles.buttonBox, Styles.center]} onPress={() => { }}>
              <Text style={Styles.buttonName}>{LableText.SAVE}</Text>
            </TouchableOpacity>
          </View>


          <View style={Styles.bottomSpace}></View>
        </Content>

      </SafeAreaLayout >
    );
  }
}


const shareSingleImage = async (qArticle, e) => {
  const shareOptions = {
    title: 'Share file',
    url: AppConstants.IMAGE_BASE_URL + '/timeline/' + qArticle,
    failOnCancel: false,
  };

  try {
    const ShareResponse = await Share.open(shareOptions);
    // setResult(JSON.stringify(ShareResponse, null, 2));
  } catch (error) {
    console.log('Error =>', error);
    // setResult('error: '.concat(getErrorString(error)));

  }
};