export { CustomerScreen } from './customer.component';
export { CustomerDetailScreen } from './customerDetail.component';
export { JobDetailScreen } from './jobDetail.component';
export { AddCustomerScreen } from './addCustomer.component';