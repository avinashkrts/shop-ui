export { ProfileScreen } from './profile.component';
export { ResumeScreen } from './resume.component';
export { EditProfileScreen } from './editProfile.component';
export { AddEducationScreen } from './addEducation.component';
export { AddAchivementScreen } from './addAchivement.component';
export { AddCertificateScreen } from './addCertificate.component';
export { AddExperienceScreen } from './addExperience.component';
export { LogoutScreen } from './Logout.component';