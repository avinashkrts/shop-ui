export { PostScreen } from './postJob.component';
export { PostScreen2 } from './postJob2.component';
export { PostScreen3 } from './postJob3.component';
export { PostScreen4 } from './postJob4.component';
export { PostScreen5 } from './postJob5.component';